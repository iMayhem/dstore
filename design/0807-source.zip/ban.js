
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const uploadsDir = path.join(DATA_DIR, 'uploads');
const metaFile = path.join(DATA_DIR, 'meta.json');
const blockedHashesFile = path.join(DATA_DIR, 'blocked_hashes.txt');

function sha256File(p) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('sha256');
    const s = fs.createReadStream(p);
    s.on('data', (d) => h.update(d));
    s.on('end', () => resolve(h.digest('hex')));
    s.on('error', reject);
  });
}

async function main() {
  const arg = process.argv[2];
  const reason = process.argv.slice(3).join(' ');
  if (!arg) {
    console.error('Usage: node ban.js <id-or-url> [reason]');
    process.exit(1);
  }

  let id = arg;
  try { id = new URL(arg).pathname.replace(/^\//, ''); } catch (_) {}
  const dot = id.indexOf('.');
  if (dot !== -1) id = id.slice(0, dot);

  let raw;
  try { raw = JSON.parse(fs.readFileSync(metaFile, 'utf8')); } catch (e) {
    console.error('Cannot read', metaFile, '-', e.message);
    process.exit(1);
  }
  const record = (Array.isArray(raw) ? raw : []).find((r) => r && r.id === id);
  if (!record) {
    console.error(`No record found for id "${id}".`);
    process.exit(1);
  }

  const filePath = path.join(uploadsDir, record.filename);
  let sha = null;
  if (fs.existsSync(filePath)) sha = await sha256File(filePath);
  else if (record.sha256) { sha = record.sha256; console.log('(file already gone, using stored hash)'); }
  else { console.error('File gone and no stored hash; nothing to ban.'); process.exit(1); }
  sha = sha.toLowerCase();

  let existing = '';
  try { existing = fs.readFileSync(blockedHashesFile, 'utf8'); } catch (_) {}
  const already = existing.split(/\r?\n/).some((l) => l.trim().toLowerCase() === sha);
  if (already) {
    console.log('hash already in blocklist');
  } else {
    const comment = `# ${new Date().toISOString()} ${id} ${record.name || ''} ${reason || ''}`.trimEnd();
    const prefix = existing && !existing.endsWith('\n') ? '\n' : '';
    fs.appendFileSync(blockedHashesFile, prefix + comment + '\n' + sha + '\n');
  }

  try { fs.unlinkSync(filePath); } catch (_) {}

  console.log('banned :', id, `(${record.name || record.filename})`);
  console.log('sha256 :', sha);
  console.log('-> file deleted, hash added to', path.basename(blockedHashesFile));
  console.log('-> any re-upload of this exact file will be rejected automatically.');
}

main().catch((e) => { console.error(e.message); process.exit(1); });
