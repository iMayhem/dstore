
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const metaFile = path.join(DATA_DIR, 'meta.json');

function envOf(key, fallback) {
  if (process.env[key] !== undefined) return process.env[key];
  try {
    const m = new RegExp(`^${key}=(.*)$`, 'm').exec(fs.readFileSync(path.join(ROOT, '.env'), 'utf8'));
    if (m) return m[1].trim();
  } catch (_) {}
  return fallback;
}

function fmt(n) {
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${Math.round(n * 10) / 10} ${u[i]}`;
}
function bar(ratio, width) {
  const filled = Math.round(Math.min(1, Math.max(0, ratio)) * width);
  return '[' + '#'.repeat(filled) + '-'.repeat(width - filled) + ']';
}
function ago(ms) {
  const s = Math.floor(ms / 1000);
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

let records;
try { records = JSON.parse(fs.readFileSync(metaFile, 'utf8')); } catch (e) {
  console.error('Cannot read', metaFile, '-', e.message);
  process.exit(1);
}
const now = Date.now();
const live = records.filter((r) => !r.expires || r.expires > now);

const totalBytes = live.reduce((a, r) => a + (r.size || 0), 0);
const limit = parseInt(envOf('STORAGE_LIMIT', '0'), 10);

console.log('');
console.log(`  files   : ${live.length}`);
if (limit > 0) {
  console.log(`  storage : ${fmt(totalBytes)} / ${fmt(limit)}  ${bar(totalBytes / limit, 24)} ${Math.round((totalBytes / limit) * 100)}%`);
} else {
  console.log(`  storage : ${fmt(totalBytes)}`);
}

const byType = {};
for (const r of live) {
  const t = (r.mime || 'other').split('/')[0] || 'other';
  byType[t] = byType[t] || { n: 0, b: 0 };
  byType[t].n++; byType[t].b += r.size || 0;
}
console.log('\n  by type :');
for (const [t, v] of Object.entries(byType).sort((a, b) => b[1].b - a[1].b)) {
  console.log(`    ${t.padEnd(12)} ${String(v.n).padStart(5)} files   ${fmt(v.b).padStart(10)}`);
}

const top = [...live].sort((a, b) => (b.size || 0) - (a.size || 0)).slice(0, 10);
console.log('\n  largest :');
for (const r of top) {
  console.log(`    ${fmt(r.size || 0).padStart(10)}  ${r.id.padEnd(9)} ${String(r.name).slice(0, 48)}  (${ago(now - (r.created || now))} old)`);
}

const soon = live.filter((r) => r.expires && r.expires - now < 48 * 3600 * 1000)
  .sort((a, b) => a.expires - b.expires).slice(0, 10);
if (soon.length) {
  console.log('\n  expiring within 48h :');
  for (const r of soon) {
    const h = Math.max(0, Math.round((r.expires - now) / 3600000));
    console.log(`    in ${String(h).padStart(3)}h   ${r.id.padEnd(9)} ${String(r.name).slice(0, 48)}  ${fmt(r.size || 0)}`);
  }
}

const burns = live.filter((r) => r.maxDownloads > 0).length;
const locked = live.filter((r) => r.pwHash).length;
const never = live.filter((r) => !r.expires).length;
console.log(`\n  burn-after-download: ${burns}   password-protected: ${locked}   no expiry: ${never}`);

let banned = 0;
try {
  banned = fs.readFileSync(path.join(DATA_DIR, 'blocked_hashes.txt'), 'utf8')
    .split(/\r?\n/).filter((l) => /^[0-9a-f]{64}$/i.test(l.trim())).length;
} catch (_) {}
console.log(`  banned hashes: ${banned}`);
console.log('');
