# 0807

**Drop a file, get a link.** A self-hosted, no-account temporary file host. No ads, no tracking, and files expire whenever you choose.

Live instance: **[0807.st](https://0807.st)** · Source: **[src.0807.st](https://src.0807.st)**

## What is 0807?

0807 is a small, fast file-hosting service. Drag in a file and you get a short link to share. There are no accounts and no ads. You decide when a file disappears, whether that is after a delay, after a number of downloads, or never, and you can lock it behind a password. It can also store short Markdown notes.

It runs as a single Node.js service that keeps everything on the filesystem, so there is no database to manage, and it sits behind nginx for TLS.

## Features

- **No account, no ads, no tracking.**
- **Drag and drop or paste** files up to 20 GB.
- **Auto-delete** after never, 1 hour, 1 day, 7 days, or 30 days.
- **Download limits** of unlimited, 1, 5, or 25 (burn after download).
- **Password protection** using a scrypt-hashed password.
- **Notes**, which are short Markdown posts with the same expiry and password options.
- **Albums** that group several files under one link.
- **Upload API** with JSON, HTML, or CSV responses, which works well with ShareX and similar tools.
- **Blocked extensions**: `exe, bat, cmd, com, scr, msi, vbs, ps1, sh, jar`.
- **Virus scanning** with ClamAV.
- **Rate limiting** and **abuse reporting** to Telegram.
- A **Tor** onion address.
- A dark and light theme, plus mascots. 🙂

## Demo

The real-world instance runs at **[0807.st](https://0807.st)**.

## Requirements

- **Node.js** 18 or newer
- **nginx** for the reverse proxy and TLS termination
- **ClamAV** for virus scanning (optional)
- A Linux server with enough disk for your uploads

## Installation

### 1. Get the code

Download the latest source as a `.zip` from [src.0807.st](https://src.0807.st), or clone your copy, then unpack it on your server.

### 2. Install dependencies

```bash
npm install
```

### 3. Configure

Copy the example config and fill in your values:

```bash
cp .env.example .env
nano .env
```

See [Configuration](#configuration) for what each setting does.

### 4. Run it

The easiest way is with [pm2](https://pm2.keymetrics.io/), which keeps the service alive and restarts it on boot:

```bash
npm install -g pm2
pm2 start server.js --name 0807
pm2 save && pm2 startup
```

You can also run it directly with `node server.js`.

### 5. Put nginx in front

0807 listens on a local port, and nginx handles TLS and forwards traffic to it. The large `client_max_body_size` matters here. It has to be at least your maximum upload size, otherwise big uploads will be rejected.

```nginx
server {
    listen 443 ssl http2;
    server_name example.com;

    client_max_body_size 20G;
    proxy_read_timeout 1h;
    proxy_send_timeout 1h;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_request_buffering off;
    }
}
```

### 6. Get a certificate

```bash
certbot --nginx -d example.com
```

## Configuration

All configuration lives in `.env`. Copy `.env.example`, then set the values below.

**Core**

| Variable | What it does |
| --- | --- |
| `SITE_NAME` | Display name of the site |
| `ACCENT` | Accent color (hex) |
| `BASE_URL` | Public URL, used in the links it returns |
| `PORT` | Local port the Node server listens on |
| `TRUST_PROXY` | Set to `true` when running behind nginx |
| `ONION_URL` | Tor address shown in the footer (optional) |
| `ABUSE_EMAIL` | Contact address for abuse reports |

**Uploads and limits**

| Variable | What it does |
| --- | --- |
| `MAX_FILE_SIZE` | Largest single upload, in bytes |
| `MAX_CHUNKED_SIZE` | Largest chunked upload, in bytes |
| `BIG_FILE_MB` | Files larger than this (in MB) use chunked handling |
| `CHUNK_SIZE` | Size of each upload chunk, in bytes |
| `BLOCKED_EXT` | Comma-separated list of blocked extensions |
| `DEFAULT_EXPIRY_HOURS` | Default auto-delete time in hours (`0` means never) |

**Storage and cleanup**

| Variable | What it does |
| --- | --- |
| `DATA_DIR` | Where uploads and metadata are stored |
| `STORAGE_LIMIT` | Total storage cap in bytes (blank for none) |
| `INACTIVITY_DAYS` | Delete files after this many days without a download (`0` disables) |

**Virus scanning (ClamAV, optional)**

| Variable | What it does |
| --- | --- |
| `CLAMAV_SCAN` | Set to `true` to scan uploads |
| `CLAMAV_SWEEP_HOURS` | How often to re-sweep stored files, in hours |
| `CLAMD_CONF` | Path to your clamd config |

**Abuse reporting (Telegram, optional)**

| Variable | What it does |
| --- | --- |
| `TELEGRAM_BOT_TOKEN` | Bot token for reports |
| `TELEGRAM_CHAT_ID` | Chat that receives reports |
| `TELEGRAM_URL` | Public Telegram link shown in the footer |

> Secrets stay in `.env`, which is never committed or published. Only `.env.example`, with empty values, is shared.

## API

Upload with a simple multipart `POST`:

```bash
curl -F file=@clip.mp4 \
     -F expiry=24 \
     -F maxdl=5 \
     -F password=hunter2 \
     https://example.com/upload
```

| Field | Meaning |
| --- | --- |
| `file` | the file to upload |
| `expiry` | hours until auto-delete (optional) |
| `maxdl` | maximum number of downloads (optional) |
| `password` | lock the file behind a password (optional) |

The response includes the share URL and a `deletion_url` you can use to remove the file early.

## Contributing

No account and no sign up. To propose a change, open any file in the source browser and use the edit button, or pick a file on the Contribute page at https://src.0807.st/contribute. You edit it in place and preview your diff before sending, and the maintainer receives it as a patch to review. To report a bug, request a feature, or ask a question, open an issue with a type and a short description on the same page.

Nothing is published automatically. Accepted changes show up in the source.

## License

Released under the [MIT License](LICENSE).
