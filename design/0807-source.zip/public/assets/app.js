(function () {
  var root = document.documentElement;
  var tb = document.getElementById('themeBtn');
  if (tb) tb.addEventListener('click', function () {
    var n = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', n);
    try { localStorage.setItem('theme', n); } catch (e) {}
  });
  var lb = document.getElementById('langBtn');
  if (lb) lb.addEventListener('click', function () {
    var n = (window.LANG === 'ru') ? 'en' : 'ru';
    document.cookie = 'lang=' + n + '; path=/; max-age=31536000; samesite=lax';
    location.reload();
  });
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.getAttribute('data-copy');
      navigator.clipboard.writeText(t).then(function () {
        var o = b.textContent;
        b.textContent = b.getAttribute('data-ok') || 'ok';
        b.classList.add('copied');
        setTimeout(function () { b.textContent = o; b.classList.remove('copied'); }, 1400);
      });
    });
  });
})();
