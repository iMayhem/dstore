# v1.3
- Per-file limit: 4 GB → 20 GB
- Storage: 400 GB → 16 TB
- Malware scanning covers the full 20 GB
# v1.2
Uploads now work without JavaScript. A plain HTML form for NoScript users and Tor Browser in its strictest mode, no scripts needed to upload. The normal JavaScript uploader is unchanged.

Also in this release, for everyone:
- "Auto-delete: never" now genuinely means never, for any file size (an old rule used to force a cap on big files)
- More forgiving upload timeouts, slow connections no longer get cut off mid-upload
The main uploader with JavaScript is the same as before: drag & drop, chunked, resumable.
# v1.1
- Storage: 55 GB → 400 GB
- Per-file limit: 2 GB → 4 GB
- Resumable uploads: a dropped connection picks up where it left off, sessions stay resumable for 24h
- Rename your uploads via your delete link
- Custom album names and note titles
- Image previews: ambient blurred background instead of empty bars
- Malware scanning now covers files in full (previously capped much lower)
- CSAM hash-matching enabled
- Full XSS/injection audit, two issues fixed
- Files not downloaded for 90 days are removed
# v1.0
- Initial release
