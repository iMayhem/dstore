
'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');

const ROOT = __dirname;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');

function envOf(key, fallback) {
  if (process.env[key] !== undefined) return process.env[key];
  try {
    const m = new RegExp(`^${key}=(.*)$`, 'm').exec(fs.readFileSync(path.join(ROOT, '.env'), 'utf8'));
    if (m) return m[1].trim();
  } catch (_) {}
  return fallback;
}
function fmt(n) {
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${Math.round(n * 10) / 10} ${u[i]}`;
}

const TOKEN = envOf('TELEGRAM_BOT_TOKEN', '');
const CHAT = envOf('TELEGRAM_CHAT_ID', '');
if (!TOKEN || !CHAT) { console.error('TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID missing in .env'); process.exit(1); }

let records = [];
try { records = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'meta.json'), 'utf8')); } catch (_) {}
const now = Date.now();
const live = records.filter((r) => !r.expires || r.expires > now);
const total = live.reduce((a, r) => a + (r.size || 0), 0);
const limit = parseInt(envOf('STORAGE_LIMIT', '0'), 10);
const week = live.filter((r) => r.created && now - r.created < 7 * 86400 * 1000);

const byType = {};
for (const r of live) {
  const t = (r.mime || 'other').split('/')[0] || 'other';
  byType[t] = (byType[t] || 0) + (r.size || 0);
}
const types = Object.entries(byType).sort((a, b) => b[1] - a[1]).slice(0, 4)
  .map(([t, b]) => `${t} ${fmt(b)}`).join(' / ');

let banned = 0;
try {
  banned = fs.readFileSync(path.join(DATA_DIR, 'blocked_hashes.txt'), 'utf8')
    .split(/\r?\n/).filter((l) => /^[0-9a-f]{64}$/i.test(l.trim())).length;
} catch (_) {}

const pct = limit > 0 ? Math.round((total / limit) * 100) : null;
const lines = [
  `0807 weekly report`,
  `files: ${live.length} (+${week.length} this week, ${fmt(week.reduce((a, r) => a + (r.size || 0), 0))})`,
  limit > 0 ? `storage: ${fmt(total)} / ${fmt(limit)} (${pct}%)` : `storage: ${fmt(total)}`,
  `by type: ${types || 'n/a'}`,
  `banned hashes: ${banned}`,
];
if (pct !== null && pct >= 80) lines.push(`warning: storage above 80%`);

const body = JSON.stringify({ chat_id: CHAT, text: lines.join('\n'), disable_web_page_preview: true });
const req = https.request({
  hostname: 'api.telegram.org',
  path: `/bot${TOKEN}/sendMessage`,
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
  timeout: 15000,
}, (r) => {
  let out = '';
  r.on('data', (d) => { out += d; });
  r.on('end', () => {
    if (r.statusCode === 200) console.log('report sent');
    else { console.error('telegram error:', r.statusCode, out.slice(0, 200)); process.exit(1); }
  });
});
req.on('error', (e) => { console.error(e.message); process.exit(1); });
req.end(body);
