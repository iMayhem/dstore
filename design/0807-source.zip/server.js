'use strict';

const express = require('express');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const rateLimit = require('express-rate-limit');
const { execFile } = require('child_process');
const QRCode = require('qrcode');
const https = require('https');
const archiver = require('archiver');

const UNLOCK_SECRET = crypto.randomBytes(32);

(function loadEnv() {
  try {
    const content = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eq = trimmed.indexOf('=');
      if (eq === -1) continue;
      const key = trimmed.slice(0, eq).trim();
      let val = trimmed.slice(eq + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (!(key in process.env)) process.env[key] = val;
    }
  } catch (_) {}
})();

const CONFIG = {
  port: parseInt(process.env.PORT || '3000', 10),
  baseUrl: (process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`).replace(/\/+$/, ''),
  siteName: process.env.SITE_NAME || '0807',
  accent: process.env.ACCENT || '#2dd4bf',
  maxFileSize: parseInt(process.env.MAX_FILE_SIZE || String(256 * 1024 * 1024), 10),
  maxChunkedSize: parseInt(process.env.MAX_CHUNKED_SIZE || String(2 * 1024 * 1024 * 1024), 10),
  chunkSize: parseInt(process.env.CHUNK_SIZE || String(16 * 1024 * 1024), 10),
  idLength: parseInt(process.env.ID_LENGTH || '7', 10),
  dataDir: process.env.DATA_DIR || path.join(__dirname, 'data'),
  blockedExtensions: (process.env.BLOCKED_EXT === undefined
    ? 'exe,bat,cmd,com,scr,msi,vbs,ps1,sh,jar'
    : process.env.BLOCKED_EXT)
    .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
  defaultExpiryHours: parseInt(process.env.DEFAULT_EXPIRY_HOURS || '0', 10),
  trustProxy: parseInt(process.env.TRUST_PROXY || '1', 10),
  abuseEmail: process.env.ABUSE_EMAIL || 'abuse@0807.st',
  onionUrl: (process.env.ONION_URL || '').replace(/^https?:\/\//, '').replace(/\/+$/, ''),
  storageLimit: parseInt(process.env.STORAGE_LIMIT || '0', 10),
  clamavScan: parseInt(process.env.CLAMAV_SCAN || '0', 10) === 1,
  clamavSweepHours: parseInt(process.env.CLAMAV_SWEEP_HOURS || '24', 10),
  clamdConf: process.env.CLAMD_CONF || '',
  bigFileMB: parseInt(process.env.BIG_FILE_MB || '500', 10),
  bigFileMaxHours: parseInt(process.env.BIG_FILE_MAX_HOURS || '720', 10),
  tgToken: process.env.TELEGRAM_BOT_TOKEN || '',
  tgChat: process.env.TELEGRAM_CHAT_ID || '',
  stripExif: parseInt(process.env.STRIP_EXIF || '1', 10) === 1,
  telegramUrl: process.env.TELEGRAM_URL || '',
  xAccel: parseInt(process.env.X_ACCEL || '0', 10) === 1,
  inactivityDays: parseInt(process.env.INACTIVITY_DAYS || '0', 10),
};

const uploadsDir = path.join(CONFIG.dataDir, 'uploads');
const tmpDir = path.join(CONFIG.dataDir, 'tmp');
const metaFile = path.join(CONFIG.dataDir, 'meta.json');
const mascotsDir = path.join(__dirname, 'public', 'assets', 'mascots');

fs.mkdirSync(uploadsDir, { recursive: true });
fs.mkdirSync(tmpDir, { recursive: true });

const meta = new Map();
const albums = new Map();
const albumsFile = path.join(CONFIG.dataDir, 'albums.json');
function loadAlbums() {
  try {
    const raw = JSON.parse(fs.readFileSync(albumsFile, 'utf8'));
    const now = Date.now();
    for (const a of raw) { if (a.expires && now > a.expires) continue; albums.set(a.id, a); }
  } catch (_) {}
}
function writeAlbums() {
  try {
    const tmp = albumsFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify([...albums.values()]));
    fs.renameSync(tmp, albumsFile);
  } catch (e) { console.error('Failed to write albums:', e); }
}

function load() {
  try {
    const raw = JSON.parse(fs.readFileSync(metaFile, 'utf8'));
    const now = Date.now();
    for (const r of raw) {
      if (r.expires && now > r.expires) continue;
      meta.set(r.id, r);
    }
  } catch (_) {}
}

function writeMeta() {
  const data = JSON.stringify([...meta.values()]);
  const tmp = metaFile + '.tmp';
  fs.writeFileSync(tmp, data);
  try { if (fs.existsSync(metaFile)) fs.copyFileSync(metaFile, metaFile + '.bak'); } catch (_) {}
  fs.renameSync(tmp, metaFile);
}

let persistTimer = null;
function persist() {
  if (persistTimer) return;
  persistTimer = setTimeout(() => {
    persistTimer = null;
    try {
      writeMeta();
    } catch (e) {
      console.error('Failed to write metadata:', e);
    }
  }, 500);
}

function persistSync() {
  try {
    writeMeta();
  } catch (_) {}
}

function removeFile(id) {
  const r = meta.get(id);
  if (!r) return false;
  try { fs.unlinkSync(path.join(uploadsDir, r.filename)); } catch (_) {}
  meta.delete(id);
  return true;
}

load();
loadAlbums();

setInterval(() => {
  const now = Date.now();
  let changed = false;
  for (const r of [...meta.values()]) {
    if (r.expires && now > r.expires) { removeFile(r.id); changed = true; continue; }
    if (CONFIG.inactivityDays > 0 && now - (r.lastAccess || r.created || 0) > CONFIG.inactivityDays * 86400000) { removeFile(r.id); changed = true; }
  }
  if (changed) persist();
  let achanged = false;
  for (const a of [...albums.values()]) {
    if (a.expires && now > a.expires) { albums.delete(a.id); achanged = true; }
  }
  if (achanged) writeAlbums();
}, 10 * 60 * 1000).unref();

const ID_ALPHABET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

function generateId(len) {
  const bytes = crypto.randomBytes(len);
  let id = '';
  for (let i = 0; i < len; i++) id += ID_ALPHABET[bytes[i] % ID_ALPHABET.length];
  return id;
}

function uniqueId() {
  let id;
  do { id = generateId(CONFIG.idLength); } while (meta.has(id));
  return id;
}

function formatBytes(n, units) {
  units = units || ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${Math.round(n * 10) / 10} ${units[i]}`;
}

const INLINE_SAFE = new Set([
  'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif',
  'image/bmp', 'image/x-icon',
  'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime',
  'audio/mpeg', 'audio/ogg', 'audio/wav', 'audio/webm', 'audio/flac',
]);

function contentDisposition(type, name) {
  const ascii = name.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
  return `${type}; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(name)}`;
}

function sanitizeExt(ext) {
  const m = /^\.([A-Za-z0-9]{1,12})$/.exec(ext);
  return m ? '.' + m[1].toLowerCase() : '';
}

const EXPIRY_OPTIONS = { '0': 0, '1': 1, '24': 24, '168': 168, '720': 720 };
function parseExpiry(v) {
  if (Object.prototype.hasOwnProperty.call(EXPIRY_OPTIONS, String(v))) {
    return EXPIRY_OPTIONS[String(v)];
  }
  return CONFIG.defaultExpiryHours;
}

function pickMascot() {
  try {
    const files = fs.readdirSync(mascotsDir)
      .filter((f) => /\.(png|jpe?g|gif|webp|avif)$/i.test(f));
    if (!files.length) return '';
    const f = files[Math.floor(Math.random() * files.length)];
    return `<img class="mascot" src="/assets/mascots/${encodeURIComponent(f)}" alt="">`;
  } catch (_) {
    return '';
  }
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = sanitizeExt(path.extname(file.originalname));
    const id = uniqueId();
    file._id = id;
    cb(null, ext ? `${id}${ext}` : id);
  },
});

function fileFilter(_req, file, cb) {
  const ext = path.extname(file.originalname).slice(1).toLowerCase();
  if (CONFIG.blockedExtensions.includes(ext)) {
    return cb(new Error(`Format ".${ext}" is not supported.`));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: CONFIG.maxFileSize, files: 1 },
});

const app = express();
app.disable('x-powered-by');
if (CONFIG.trustProxy) app.set('trust proxy', CONFIG.trustProxy);

const PAGE_CSP = "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'geolocation=(), camera=(), microphone=(), interest-cohort=()');
  const xfp = req.headers['x-forwarded-proto'];
  if (req.secure || (xfp && String(xfp).split(',')[0].trim() === 'https')) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  next();
});

const uploadLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res, _next, options) => res.status(options.statusCode).json({ error: STRINGS[pickLang(req)].err.rate }),
});

const MASCOT_DIR = path.join(__dirname, 'public', 'assets', 'mascots');
let _mascots = ['/assets/mascot.png'];
let _mascotsAt = 0;
function randMascot() {
  const now = Date.now();
  if (now - _mascotsAt > 30000) {
    try {
      const list = fs.readdirSync(MASCOT_DIR)
        .filter((f) => /\.(png|webp|avif|jpe?g|gif)$/i.test(f))
        .map((f) => '/assets/mascots/' + f);
      if (list.length) _mascots = list;
    } catch (_) {}
    _mascotsAt = now;
  }
  return _mascots[Math.floor(Math.random() * _mascots.length)];
}

const SQUIG = '<svg class="squig" viewBox="0 0 160 13" fill="none" aria-hidden="true"><path d="M3 8.5 C 16 2.5, 28 12, 42 7.5 S 68 2.5, 82 8.5 S 108 12.5, 122 6.5 S 148 4, 157 8.5" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"/></svg>';

const TG_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M21.94 4.27 18.9 19.1c-.23 1.02-.84 1.27-1.7.79l-4.7-3.46-2.27 2.18c-.25.25-.46.46-.95.46l.34-4.8 8.73-7.89c.38-.34-.08-.53-.59-.19L6.7 12.55 2.05 11.1c-1.01-.32-1.03-1.01.21-1.5L20.3 2.96c.84-.31 1.58.2 1.64 1.31Z"/></svg>';
const GH_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.57.1.78-.25.78-.55 0-.27-.01-1-.02-1.96-3.2.69-3.88-1.54-3.88-1.54-.52-1.33-1.28-1.69-1.28-1.69-1.05-.71.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.76 2.7 1.25 3.36.96.1-.75.4-1.25.73-1.54-2.55-.29-5.24-1.28-5.24-5.67 0-1.25.45-2.28 1.18-3.08-.12-.29-.51-1.46.11-3.04 0 0 .96-.31 3.15 1.18a10.9 10.9 0 0 1 5.74 0c2.19-1.49 3.15-1.18 3.15-1.18.62 1.58.23 2.75.11 3.04.74.8 1.18 1.83 1.18 3.08 0 4.4-2.69 5.37-5.25 5.66.41.36.78 1.06.78 2.14 0 1.55-.01 2.8-.01 3.18 0 .31.21.66.79.55A11.51 11.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>';
const GH_LINK = `<a class="nav-tg" href="https://src.0807.st" rel="noreferrer">${GH_ICON}<span>Source</span></a>`;

const STRINGS = {
  en: {
    desc: 'Upload files and get short links.',
    tagline: 'Simple, private file hosting.',
    headline: 'Drop a file, get a link.',
    subtext: 'No account, no ads. Files disappear whenever you choose.',
    legend: 'upload',
    drop: 'Drag a file here',
    or: 'or',
    select: 'Choose file',
    maxPrefix: 'max.',
    expLabel: 'auto-delete',
    never: 'never', h1: '1 hour', d1: '1 day', d7: '7 days', d30: '30 days',
    dlLabel: 'max downloads', dlUnlim: '∞',
    pwLabel: 'password', pwPlaceholder: 'optional',
    pasteOpen: 'write a note', pasteGo: 'create note', pastePh: 'Write your note. Markdown: **bold** *italic* # heading - list > quote', pasteHint: 'The password and self-destruct options above also apply to notes.', sig: '0807 · self-hosted · no accounts · v1.3',
    blockedPrefix: 'blocked:',
    navRules: 'Rules',
    navReport: 'Report',
    navTelegram: 'Telegram',
    navDonate: 'Donate',
    donate: {
      title: 'Support the project',
      intro: '0807 runs on its own server and shows no ads. If you find it useful, you can support it and help cover the server costs. Any amount helps.',
      hint: 'Scan the QR code or copy the address.',
      thanks: 'Thank you for your support.',
      back: '← home',
    },
    langSwitch: 'Russian',
    noneWord: 'none',
    storageBanner: 'Uploads are temporarily paused: the storage limit has been reached. Please try again later.',
    usageLabel: 'storage',
    pw: {
      title: 'Protected file',
      msg: 'Enter the password to access this file.',
      placeholder: 'password',
      submit: 'unlock',
      wrong: 'Wrong password.',
    },
    mini: {
      notfound: { title: 'Not found', msg: 'This file does not exist or has been deleted.' },
      badlink: { title: 'Invalid link', msg: 'The link is invalid or the file has already been deleted.' },
      deleted: { title: 'File deleted', msg: 'The file has been removed from the server.' },
      error: { title: 'Server error', msg: 'Something went wrong. Please try again later.' },
      home: '← home',
    },
    js: {
      copy: 'copy', copied_ok: 'ok', dl_link: 'download link', copy_all: 'copy all links ({n})', preview_lbl: 'preview', album_make: 'create album ({n})', album_label: 'Album', note_label: 'note', units: ['B', 'KB', 'MB', 'GB', 'TB', 'PB'],
      expires: 'expires ', del: 'delete',
      alt_clearnet: '// also on the web',
      burns: 'burns after {n} download(s)', protected_lbl: 'password-protected',
      qr_show: 'QR', qr_hide: 'hide',
      theme_dark: 'dark', theme_light: 'light',
      full: 'Storage is full, uploads are unavailable.',
      err_too_large: 'file too large (max. {x})',
      err_empty: 'empty file', err_conn: 'connection lost', err_generic: 'error {n}',
    },
    err: {
      too_large: 'File too large (max. {x}).',
      not_received: 'File not received.',
      empty: 'Empty file.',
      upload_fail: 'Upload failed.',
      storage_full: 'Server storage is full. Try again later.',
      blocked: 'This file is blocked and cannot be uploaded.',
      infected: 'Malware detected. Upload rejected.',
      process_fail: 'Could not process the file.',
      rate: 'Too many uploads. Try again in a few minutes.',
    },
    rules: {
      title: 'Terms of use',
      lead: 'By uploading to {site} you agree to these terms. Breaking them means your files are deleted, and serious cases are reported to law enforcement.',
      hProhibited: 'Prohibited',
      csam: '<strong>Sexual content involving minors (CSAM)</strong> is removed instantly and reported to law enforcement.',
      terror: '<strong>Terrorist or extremist material</strong>, including incitement to violence.',
      malware: '<strong>Malware, viruses, and phishing.</strong>',
      abuse: '<strong>Harassment, threats, or doxxing.</strong>',
      illegal: '<strong>Anything else illegal</strong> under applicable law.',
      hPrivacy: 'Privacy',
      privacy: 'No IP addresses, no connection logs. We keep only basic file info, deleted together with the file. Files are never shared, and only someone with the link can open one.',
      keepYes: 'kept: file name, size, type, date',
      keepNo: 'not kept: IP, connection logs, who uploaded',
      hReport: 'Reporting',
      report: 'Files that break these terms are deleted without notice and access may be blocked. To report something, email {mail} with the link and the reason.',
      back: '← home',
    },
  },
};

function pickLang(_req) {
  return 'en';
}

const template = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
function renderHome(req) {
  const lang = pickLang(req);
  const S = STRINGS[lang];
  const onion = CONFIG.onionUrl;
  const reqHost = (req.headers['host'] || '').toLowerCase();
  const viaOnion = reqHost.endsWith('.onion');
  let onionHtml = '';
  if (viaOnion && CONFIG.baseUrl) {
    let webHost = CONFIG.baseUrl;
    try { webHost = new URL(CONFIG.baseUrl).host; } catch (_) {}
    onionHtml = `<div class="onion"><span class="onion-tag">web</span><a class="onion-addr" href="${CONFIG.baseUrl}" rel="noreferrer">${webHost}</a><button type="button" class="act" id="onionCopy">${S.js.copy}</button></div>`;
  } else if (onion) {
    onionHtml = `<div class="onion"><span class="onion-tag">tor</span><a class="onion-addr" href="http://${onion}" rel="noreferrer">${onion}</a><button type="button" class="act" id="onionCopy">${S.js.copy}</button></div>`;
  }
  const tg = CONFIG.telegramUrl;
  const tgHtml = tg
    ? `<a class="nav-tg" href="${tg}" rel="noreferrer">${TG_ICON}<span>${S.navTelegram}</span></a>`
    : '';
  const used = currentStorageBytes();
  const full = CONFIG.storageLimit > 0 && used >= CONFIG.storageLimit;
  const noticeHtml = full ? `<div class="banner">${S.storageBanner}</div>` : '';
  let usageHtml = '';
  if (CONFIG.storageLimit > 0) {
    const pct = Math.min(100, Math.round((used / CONFIG.storageLimit) * 100));
    usageHtml = `<div class="usage"><span class="usage-lbl">${S.usageLabel}</span><div class="bar"><div class="bar-fill" style="width:${pct}%"></div></div><span class="usage-num">${formatBytes(used, S.js.units)} / ${formatBytes(CONFIG.storageLimit, S.js.units)}</span></div>`;
  }
  const i18nScript = `<script>window.LANG=${JSON.stringify(lang)};window.STORAGE_FULL=${full};window.T=${JSON.stringify(S.js)};</script>`;
  const nojsLimit = viaOnion ? '200 MB' : '95 MB';
  return template
    .replace(/\{\{NOJS_LIMIT\}\}/g, nojsLimit)
    .replace(/\{\{MASCOT\}\}/g, () => randMascot())
    .replace(/\{\{LANG\}\}/g, lang)
    .replace(/\{\{ACCENT\}\}/g, CONFIG.accent)
    .replace(/\{\{SITE_NAME\}\}/g, CONFIG.siteName)
    .replace(/\{\{MAX_SIZE\}\}/g, formatBytes(CONFIG.maxChunkedSize, S.js.units))
    .replace(/\{\{MAX_SIZE_BYTES\}\}/g, String(CONFIG.maxChunkedSize))
    .replace(/\{\{BLOCKED\}\}/g, CONFIG.blockedExtensions.join(', ') || S.noneWord)
    .replace(/\{\{ABUSE_EMAIL\}\}/g, CONFIG.abuseEmail)
    .replace(/\{\{ONION\}\}/g, () => onionHtml)
    .replace(/\{\{TELEGRAM\}\}/g, () => tgHtml + GH_LINK)
    .replace(/\{\{I18N_SCRIPT\}\}/g, () => i18nScript)
    .replace(/\{\{NOTICE\}\}/g, () => noticeHtml)
    .replace(/\{\{T_DESC\}\}/g, S.desc)
    .replace(/\{\{T_TAGLINE\}\}/g, S.tagline)
    .replace(/\{\{T_HEADLINE\}\}/g, S.headline)
    .replace(/\{\{T_SUBTEXT\}\}/g, S.subtext)
    .replace(/\{\{T_OR\}\}/g, S.or)
    .replace(/\{\{T_LEGEND\}\}/g, S.legend)
    .replace(/\{\{T_DROP\}\}/g, S.drop)
    .replace(/\{\{T_SELECT\}\}/g, S.select)
    .replace(/\{\{T_MAXPREFIX\}\}/g, S.maxPrefix)
    .replace(/\{\{T_EXPLABEL\}\}/g, S.expLabel)
    .replace(/\{\{T_NEVER\}\}/g, S.never)
    .replace(/\{\{T_1H\}\}/g, S.h1)
    .replace(/\{\{T_1D\}\}/g, S.d1)
    .replace(/\{\{T_7D\}\}/g, S.d7)
    .replace(/\{\{T_30D\}\}/g, S.d30)
    .replace(/\{\{T_DLLABEL\}\}/g, S.dlLabel)
    .replace(/\{\{T_DLUNLIMITED\}\}/g, S.dlUnlim)
    .replace(/\{\{T_PWLABEL\}\}/g, S.pwLabel)
    .replace(/\{\{T_PWPLACEHOLDER\}\}/g, S.pwPlaceholder)
    .replace(/\{\{T_PASTE_OPEN\}\}/g, S.pasteOpen)
    .replace(/\{\{T_PASTE_GO\}\}/g, S.pasteGo)
    .replace(/\{\{T_PASTE_PH\}\}/g, S.pastePh)
    .replace(/\{\{T_PASTE_HINT\}\}/g, S.pasteHint)
    .replace(/\{\{T_SIG\}\}/g, S.sig)
    .replace(/\{\{T_BLOCKEDPREFIX\}\}/g, S.blockedPrefix)
    .replace(/\{\{T_RULES\}\}/g, S.navRules)
    .replace(/\{\{T_REPORT\}\}/g, S.navReport)
    .replace(/\{\{T_DONATE\}\}/g, S.navDonate)
    .replace(/\{\{T_LANGSWITCH\}\}/g, S.langSwitch)
    .replace(/\{\{USAGE\}\}/g, () => usageHtml)
    .replace(/\{\{OG_TITLE\}\}/g, CONFIG.siteName)
    .replace(/\{\{OG_DESC\}\}/g, S.tagline)
    .replace(/\{\{OG_IMAGE\}\}/g, () => `${CONFIG.baseUrl}/assets/og.png`)
    .replace(/\{\{OG_URL\}\}/g, () => CONFIG.baseUrl);
}

app.get('/', (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  res.send(renderHome(req));
});

app.use('/assets', express.static(path.join(__dirname, 'public', 'assets'), {
  maxAge: '7d',
  index: false,
  dotfiles: 'ignore',
}));

app.get('/sharex', (_req, res) => {
  const config = {
    Version: '15.0.0',
    Name: CONFIG.siteName,
    DestinationType: 'ImageUploader, FileUploader, TextUploader',
    RequestMethod: 'POST',
    RequestURL: `${CONFIG.baseUrl}/upload`,
    Body: 'MultipartFormData',
    FileFormName: 'file',
    URL: '{json:url}',
    DeletionURL: '{json:deletion_url}',
    ErrorMessage: '{json:error}',
  };
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${CONFIG.siteName}.sxcu"`);
  res.send(JSON.stringify(config, null, 2));
});

app.get('/robots.txt', (_req, res) => {

  const aiBots = ['Amazonbot', 'Applebot-Extended', 'Bytespider', 'CCBot', 'ClaudeBot',
    'Google-Extended', 'GPTBot', 'meta-externalagent', 'PerplexityBot', 'Meta-ExternalFetcher'];
  const lines = ['User-agent: *', 'Allow: /$', 'Allow: /api$', 'Allow: /rules$', 'Allow: /donate$', 'Allow: /assets/', 'Disallow: /', ''];
  for (const b of aiBots) lines.push(`User-agent: ${b}`, 'Disallow: /', '');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(lines.join('\n'));
});

app.get('/api', (req, res) => {
  const B = CONFIG.baseUrl;
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const curl = esc(`curl -F file=@photo.jpg ${B}/upload`);
  const curlFull = esc('curl -F file=@secret.zip \\\n' +
    '     -F expiry=24 \\\n' +
    '     -F maxdl=1 \\\n' +
    '     -F password=hunter2 \\\n' +
    `     ${B}/upload`);
  const resp = esc(`{
  "url": "${B}/Ab3dEfG.jpg",
  "deletion_url": "${B}/d/<token>",
  "name": "photo.jpg",
  "size": 482133,
  "expires": 0,
  "max_downloads": 0,
  "protected": false
}`);
  const css = `.api{margin-top:clamp(1.6rem,5vh,2.4rem);text-align:left}
.api h2{font-size:1.12em;font-weight:900;margin:2rem 0 .5rem}
.api h2:first-child{margin-top:0}
.api p{margin:.55rem 0}
.code{background:var(--card);border:2px solid var(--ink);border-radius:14px;box-shadow:4px 4px 0 var(--shadow);
      font-family:var(--mono);font-size:.86em;font-weight:600;line-height:1.55;
      padding:.85rem 1rem;overflow-x:auto;white-space:pre;margin:.7rem 0 1.1rem}
.fields{margin:.4rem 0 0;padding-left:1.35rem}
.fields li{margin:.45rem 0}
.fields li::marker{color:var(--accent)}
.fields code{font-family:var(--mono);font-weight:800;color:var(--accent)}
.api .note2{color:var(--muted);font-weight:600;font-size:.9em}`;
  const main = `
<section class="phero">
  <div><h1>API</h1>${SQUIG}<p>One POST request. No key, no account. Perfect for scripts, bots and ShareX.</p></div>
</section>
<div class="api">
  <h2>Upload a file</h2>
  <div class="code">${curl}</div>
  <p>Optional form fields:</p>
  <ul class="fields">
    <li><code>expiry</code>: hours before auto-delete (<code>0</code> never, <code>1</code>, <code>24</code>, <code>168</code>, <code>720</code>)</li>
    <li><code>maxdl</code>: self-destruct after N downloads (<code>0</code> = unlimited)</li>
    <li><code>password</code>: protect the file with a password</li>
  </ul>
  <div class="code">${curlFull}</div>
  <h2>Response</h2>
  <div class="code">${resp}</div>
  <p class="note2">Keep <strong>deletion_url</strong>: opening it removes the file. Append <strong>?dl=1</strong> to any file link to force a download instead of inline display. Add <strong>/p/</strong> before the id for the pretty viewer page.</p>
  <h2>ShareX</h2>
  <p>Download the ready-made config and double-click it: <a href="/sharex">${esc(CONFIG.siteName)}.sxcu</a></p>
  <h2>Limits</h2>
  <p class="note2">Max ${formatBytes(CONFIG.maxChunkedSize, STRINGS.en.js.units)} per file &middot; blocked extensions: ${esc(CONFIG.blockedExtensions.join(', ') || 'none')} &middot; every upload is scanned for malware.${CONFIG.inactivityDays > 0 ? ` Files not downloaded for ${CONFIG.inactivityDays} days are removed.` : ''}${CONFIG.bigFileMB > 0 ? ` Files over ${CONFIG.bigFileMB} MB expire after ${Math.round(CONFIG.bigFileMaxHours / 24)} days at most.` : ''}</p>
</div>`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  res.send(pageChrome(req, { title: `API / ${CONFIG.siteName}`, main, css, robots: 'index, follow' }));
});

app.get('/changelog', (req, res) => {
  let raw = '';
  try { raw = fs.readFileSync(path.join(__dirname, 'changelog.md'), 'utf8'); } catch (_) {}
  if (!raw) return res.status(404).send(miniPage(req, 'notfound'));
  const css = `.note-body{font-size:1rem;line-height:1.7}
.note-body h2{font-size:1.4rem;margin:1.8rem 0 .6rem}
.note-body ul{margin:.6rem 0;padding-left:1.4rem}
.note-body li{margin:.3rem 0}`;
  const main = `<div class="content"><h1>Changelog</h1><article class="note-body">${renderMarkdown(raw)}</article></div>`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  res.setHeader('Cache-Control', 'no-cache');
  res.send(pageChrome(req, { title: `Changelog / ${CONFIG.siteName}`, main, css, robots: 'index, follow', footer: '<a class="backlink" href="/">\u2190 home</a>' }));
});

app.get('/rules', (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  res.send(rulesPage(req));
});

app.get('/favicon.ico', (_req, res) => res.redirect(301, '/assets/favicon.ico'));

app.get('/donate', (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  res.send(donatePage(req));
});

let CONFIGURED_HOST = '';
try { CONFIGURED_HOST = new URL(CONFIG.baseUrl).host.toLowerCase(); } catch (_) {}
function baseFor(req) {
  const host = (req.headers['host'] || '').toLowerCase();
  const isOnion = host.endsWith('.onion');
  if (!host || (!isOnion && host !== CONFIGURED_HOST)) return CONFIG.baseUrl;
  const xf = req.headers['x-forwarded-proto'];
  const proto = isOnion ? 'http' : (xf ? String(xf).split(',')[0].trim() : (req.secure ? 'https' : 'http'));
  return `${proto}://${host}`;
}

function uploadResponse(req, record, deleteToken) {
  const base = baseFor(req);
  const out = {
    url: `${base}/${record.filename}`,
    deletion_url: `${base}/d/${deleteToken}`,
    name: record.name,
    size: record.size,
    expires: record.expires,
    max_downloads: record.maxDownloads || 0,
    protected: !!record.pwHash,
  };
  const host = (req.headers['host'] || '').toLowerCase();
  if (host.endsWith('.onion') && CONFIG.baseUrl) {
    out.alt_url = `${CONFIG.baseUrl}/${record.filename}`;
  }
  return out;
}

function unlockToken(id) {
  return crypto.createHmac('sha256', UNLOCK_SECRET).update(id).digest('hex');
}
function parseCookies(req) {
  const out = {};
  const c = req.headers.cookie;
  if (!c) return out;
  c.split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > -1) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function hasValidUnlock(req, id) {
  const t = parseCookies(req)['ul_' + id];
  if (!t) return false;
  const expected = unlockToken(id);
  try { return t.length === expected.length && crypto.timingSafeEqual(Buffer.from(t), Buffer.from(expected)); } catch (_) { return false; }
}

const blockedHashesFile = path.join(CONFIG.dataDir, 'blocked_hashes.txt');
function sha256File(p) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('sha256');
    const s = fs.createReadStream(p);
    s.on('data', (d) => h.update(d));
    s.on('end', () => resolve(h.digest('hex')));
    s.on('error', reject);
  });
}
function isBlockedHash(hex) {
  try {
    const data = fs.readFileSync(blockedHashesFile, 'utf8');
    return data.split(/\r?\n/).some((line) => line.trim().toLowerCase() === hex);
  } catch (_) { return false; }
}

function currentStorageBytes() {
  let total = 0;
  for (const r of meta.values()) total += (r.size || 0);
  return total;
}
function clamdscanBaseArgs() {
  const a = ['--no-summary'];
  if (CONFIG.clamdConf) a.push('--config-file=' + CONFIG.clamdConf);
  else a.push('--fdpass');
  return a;
}
function clamScan(p) {
  return new Promise((resolve) => {
    execFile('clamdscan', [...clamdscanBaseArgs(), p], { timeout: 600000 }, (err) => {
      if (err && err.code === 1) return resolve({ infected: true });
      resolve({ infected: false });
    });
  });
}

function tgSend(text) {
  if (!CONFIG.tgToken || !CONFIG.tgChat) return;
  const body = JSON.stringify({ chat_id: CONFIG.tgChat, text, disable_web_page_preview: true });
  const req = https.request({
    hostname: 'api.telegram.org',
    path: `/bot${CONFIG.tgToken}/sendMessage`,
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    timeout: 10000,
  }, (r) => { r.resume(); });
  req.on('error', () => {});
  req.on('timeout', () => req.destroy());
  req.end(body);
}

let storageAlerted = false;
function checkStorageAlert() {
  if (CONFIG.storageLimit <= 0) return;
  const pct = currentStorageBytes() / CONFIG.storageLimit;
  if (pct >= 0.8 && !storageAlerted) {
    storageAlerted = true;
    tgSend(`storage alert: ${Math.round(pct * 100)}% used (${formatBytes(currentStorageBytes())} / ${formatBytes(CONFIG.storageLimit)})`);
  } else if (pct < 0.75) {
    storageAlerted = false;
  }
}

function appendBlockedHash(sha, comment) {
  sha = String(sha).toLowerCase();
  let existing = '';
  try { existing = fs.readFileSync(blockedHashesFile, 'utf8'); } catch (_) {}
  if (existing.split(/\r?\n/).some((l) => l.trim().toLowerCase() === sha)) return false;
  const prefix = existing && !existing.endsWith('\n') ? '\n' : '';
  fs.appendFileSync(blockedHashesFile, `${prefix}# ${new Date().toISOString()} ${comment || ''}`.trimEnd() + '\n' + sha + '\n');
  return true;
}

let sweepRunning = false;
function sweepClamav() {
  if (!CONFIG.clamavScan || sweepRunning) return;
  sweepRunning = true;
  execFile('clamdscan', [...clamdscanBaseArgs(), '--infected', uploadsDir],
    { timeout: 0, maxBuffer: 16 * 1024 * 1024 }, async (err, stdout) => {
      sweepRunning = false;
      if (err && err.code !== 1) {
        if (err.code !== 0) console.error('[clamav] sweep failed:', err.message);
        return;
      }
      const hits = String(stdout || '').split('\n')
        .map((l) => /^(.*?): (.+) FOUND$/.exec(l.trim()))
        .filter(Boolean);
      let removed = 0;
      for (const m of hits) {
        const fp = m[1];
        const sig = m[2];
        const fname = path.basename(fp);
        let rec = null;
        for (const r of meta.values()) { if (r.filename === fname) { rec = r; break; } }
        try {
          const sha = (rec && rec.sha256) || await sha256File(fp);
          appendBlockedHash(sha, `clamav ${sig} ${fname}`);
        } catch (_) {}
        try { fs.unlinkSync(fp); } catch (_) {}
        if (rec) meta.delete(rec.id);
        removed++;
        console.log(`[clamav] removed infected file ${fname} (${sig})`);
      }
      if (removed) { persist(); tgSend(`clamav sweep removed ${removed} infected file(s)`); }
    });
}
if (CONFIG.clamavScan && CONFIG.clamavSweepHours > 0) {
  setTimeout(sweepClamav, 5 * 60 * 1000).unref();
  setInterval(sweepClamav, CONFIG.clamavSweepHours * 3600 * 1000).unref();
}

function stripExif(p, mime) {
  return new Promise((resolve) => {
    if (!CONFIG.stripExif || !/^image\//.test(mime || '')) return resolve();
    execFile('exiftool', ['-all=', '-tagsfromfile', '@', '-Orientation', '-overwrite_original', '-q', '-m', p], { timeout: 20000 }, () => resolve());
  });
}

const escHtml = (x) => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const chunkSessions = new Map();

function cleanupSession(sess) {
  if (!sess) return;
  try { fs.unlinkSync(sess.tmpPath); } catch (_) {}
  chunkSessions.delete(sess.id);
}

setInterval(() => {
  const now = Date.now();
  for (const sess of chunkSessions.values()) {
    if (now - sess.touched > 24 * 3600 * 1000) cleanupSession(sess);
  }
  try {
    for (const f of fs.readdirSync(tmpDir)) {
      const fp = path.join(tmpDir, f);
      try { if (now - fs.statSync(fp).mtimeMs > 25 * 3600 * 1000) fs.unlinkSync(fp); } catch (_) {}
    }
  } catch (_) {}
}, 30 * 60 * 1000).unref();

async function finalizeStoredFile(opts) {
  const E = STRINGS[opts.lang].err;
  let size = 0;
  try { size = fs.statSync(opts.filePath).size; } catch (_) {}
  if (size === 0) { try { fs.unlinkSync(opts.filePath); } catch (_) {} return { status: 400, error: E.empty }; }
  if (CONFIG.storageLimit > 0 && currentStorageBytes() + size > CONFIG.storageLimit) {
    try { fs.unlinkSync(opts.filePath); } catch (_) {}
    return { status: 507, error: E.storage_full };
  }
  const sha = await sha256File(opts.filePath);
  if (isBlockedHash(sha)) { try { fs.unlinkSync(opts.filePath); } catch (_) {} return { status: 451, error: E.blocked }; }
  if (CONFIG.clamavScan) {
    if (size <= 50 * 1024 * 1024) {
      const scan = await clamScan(opts.filePath);
      if (scan.infected) { try { fs.unlinkSync(opts.filePath); } catch (_) {} return { status: 422, error: E.infected }; }
    } else {
      setImmediate(() => {
        clamScan(opts.filePath).then((scan) => {
          if (scan.infected) {
            const rec = meta.get(opts.id);
            if (rec) { removeFile(opts.id); persist(); }
            else { try { fs.unlinkSync(opts.filePath); } catch (_) {} }
            tgSend('[clamav] infected file removed after async scan: ' + opts.id);
          }
        }).catch(() => {});
      });
    }
  }
  await stripExif(opts.filePath, opts.mimetype);
  try { size = fs.statSync(opts.filePath).size; } catch (_) {}
  let hours = parseExpiry(opts.expiryRaw);

  if (CONFIG.bigFileMB > 0 && size > CONFIG.bigFileMB * 1024 * 1024) {
    if (hours === 0 || hours > CONFIG.bigFileMaxHours) hours = CONFIG.bigFileMaxHours;
  }
  const deleteToken = crypto.randomBytes(16).toString('hex');

  let maxDownloads = parseInt(opts.maxDownloadsRaw, 10);
  if (!Number.isFinite(maxDownloads) || maxDownloads < 0) maxDownloads = 0;
  if (maxDownloads > 100000) maxDownloads = 100000;

  let pwSalt = '';
  let pwHash = '';
  if (typeof opts.password === 'string' && opts.password.length > 0) {
    pwSalt = crypto.randomBytes(16).toString('hex');
    pwHash = crypto.scryptSync(opts.password, pwSalt, 32).toString('hex');
  }

  const record = {
    id: opts.id,
    filename: opts.filename,
    name: opts.originalName,
    mime: opts.mimetype || 'application/octet-stream',
    size,
    sha256: sha,
    created: Date.now(),
    expires: hours ? Date.now() + hours * 3600 * 1000 : 0,
    deleteToken,
    maxDownloads,
    downloads: 0,
    pwSalt,
    pwHash,
    note: opts.note === true,
  };
  meta.set(opts.id, record);
  persist();
  checkStorageAlert();
  return { ok: true, record, deleteToken };
}

app.post('/upload', uploadLimiter, (req, res) => {
  upload.single('file')(req, res, async (err) => {
    const lang = pickLang(req);
    const E = STRINGS[lang].err;
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: E.too_large.replace('{x}', formatBytes(CONFIG.maxFileSize, STRINGS[lang].js.units)) });
      }
      return res.status(400).json({ error: E.upload_fail });
    }
    if (!req.file) return res.status(400).json({ error: E.not_received });
    try {
      const r = await finalizeStoredFile({
        filePath: req.file.path,
        id: req.file._id,
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimetype: req.file.mimetype,
        expiryRaw: req.body && req.body.expiry,
        maxDownloadsRaw: req.body && req.body.maxdl,
        password: req.body && req.body.password,
        lang,
      });
      if (!r.ok) {
        if (req.body && req.body.nojs) {
          const main = `<div class="content"><h1>Upload failed</h1><p class="lead">${escHtml(r.error || 'error')}</p><p><a class="backlink" href="/">\u2190 back</a></p></div>`;
          return res.status(r.status).send(pageChrome(req, { title: `Error / ${CONFIG.siteName}`, main }));
        }
        return res.status(r.status).json({ error: r.error });
      }
      if (req.body && req.body.nojs) {
        const resp = uploadResponse(req, r.record, r.deleteToken);
        const delUrl = baseFor(req) + '/d/' + r.deleteToken;
        const main = `<div class="content"><h1>File uploaded</h1>
<p class="lead">Your link:</p>
<p style="word-break:break-all;font-weight:700"><a href="${escHtml(resp.url)}">${escHtml(resp.url)}</a></p>
<p class="lead" style="margin-top:1.4rem">Deletion link (keep it safe):</p>
<p style="word-break:break-all;font-size:.9em"><a href="${escHtml(delUrl)}">${escHtml(delUrl)}</a></p>
<p style="margin-top:1.6rem"><a class="backlink" href="/">\u2190 upload another</a></p></div>`;
        return res.send(pageChrome(req, { title: `Uploaded / ${CONFIG.siteName}`, main }));
      }
      res.json(uploadResponse(req, r.record, r.deleteToken));
    } catch (e) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
      res.status(500).json({ error: E.process_fail });
    }
  });
});

app.post('/upload/init', uploadLimiter, express.json({ limit: '8kb' }), (req, res) => {
  const lang = pickLang(req);
  const E = STRINGS[lang].err;
  const body = req.body || {};
  const name = typeof body.name === 'string' ? body.name : '';
  const size = parseInt(body.size, 10);
  if (!name) return res.status(400).json({ error: E.upload_fail });
  const ext = path.extname(name).slice(1).toLowerCase();
  if (CONFIG.blockedExtensions.includes(ext)) return res.status(400).json({ error: E.upload_fail });
  if (!Number.isFinite(size) || size <= 0) return res.status(400).json({ error: E.empty });
  if (size > CONFIG.maxChunkedSize) {
    return res.status(413).json({ error: E.too_large.replace('{x}', formatBytes(CONFIG.maxChunkedSize, STRINGS[lang].js.units)) });
  }
  if (CONFIG.storageLimit > 0 && currentStorageBytes() + size > CONFIG.storageLimit) {
    return res.status(507).json({ error: E.storage_full });
  }
  const uploadId = crypto.randomBytes(16).toString('hex');
  const tmpPath = path.join(tmpDir, uploadId + '.part');
  try { fs.writeFileSync(tmpPath, ''); } catch (_) { return res.status(500).json({ error: E.process_fail }); }
  chunkSessions.set(uploadId, {
    id: uploadId, tmpPath, name,
    mime: typeof body.mime === 'string' ? body.mime : '',
    declared: size, received: 0, touched: Date.now(),
  });
  res.json({ uploadId, chunkSize: CONFIG.chunkSize });
});

app.get('/upload/status', (req, res) => {
  const sess = chunkSessions.get(String(req.query.id || ''));
  if (!sess) return res.status(404).json({ error: 'unknown' });
  sess.touched = Date.now();
  let sz = 0;
  try { sz = fs.statSync(sess.tmpPath).size; } catch (_) {}
  sess.received = sz;
  res.json({ received: sz, chunkSize: CONFIG.chunkSize, declared: sess.declared });
});

app.post('/upload/chunk', (req, res) => {
  const lang = pickLang(req);
  const E = STRINGS[lang].err;
  const sess = chunkSessions.get(String(req.query.id || ''));
  if (!sess) return res.status(404).json({ error: E.upload_fail });
  sess.touched = Date.now();
  const offset = parseInt(req.query.offset, 10);
  if (Number.isFinite(offset)) {
    let cur = 0;
    try { cur = fs.statSync(sess.tmpPath).size; } catch (_) {}
    if (cur !== offset) { req.resume(); return res.status(409).json({ received: cur }); }
  }
  const ws = fs.createWriteStream(sess.tmpPath, { flags: 'a' });
  let failed = false;
  ws.on('error', () => { failed = true; try { sess.received = fs.statSync(sess.tmpPath).size; } catch (_) {} if (!res.headersSent) res.status(500).json({ error: E.process_fail }); });
  req.on('error', () => { try { ws.destroy(); } catch (_) {} });
  ws.on('finish', () => {
    if (failed) return;
    let sz = sess.received;
    try { sz = fs.statSync(sess.tmpPath).size; } catch (_) {}
    sess.received = sz;
    if (sz > sess.declared) {
      cleanupSession(sess);
      return res.status(413).json({ error: E.too_large.replace('{x}', formatBytes(CONFIG.maxChunkedSize, STRINGS[lang].js.units)) });
    }
    res.json({ received: sz });
  });
  req.pipe(ws);
});

app.post('/upload/finish', express.json({ limit: '8kb' }), async (req, res) => {
  const lang = pickLang(req);
  const E = STRINGS[lang].err;
  const body = req.body || {};
  const sess = chunkSessions.get(String(body.id || ''));
  if (!sess) return res.status(404).json({ error: E.upload_fail });
  chunkSessions.delete(sess.id);
  try {
    if (sess.received === 0) { try { fs.unlinkSync(sess.tmpPath); } catch (_) {} return res.status(400).json({ error: E.empty }); }
    const id = uniqueId();
    const ext = sanitizeExt(path.extname(sess.name));
    const filename = ext ? `${id}${ext}` : id;
    const finalPath = path.join(uploadsDir, filename);
    fs.renameSync(sess.tmpPath, finalPath);
    const r = await finalizeStoredFile({
      filePath: finalPath, id, filename,
      originalName: sess.name, mimetype: sess.mime,
      expiryRaw: body.expiry,
      maxDownloadsRaw: body.maxdl,
      password: body.password,
      lang,
    });
    if (!r.ok) return res.status(r.status).json({ error: r.error });
    res.json(uploadResponse(req, r.record, r.deleteToken));
  } catch (e) {
    try { fs.unlinkSync(sess.tmpPath); } catch (_) {}
    res.status(500).json({ error: E.process_fail });
  }
});

app.get('/d/:token', (req, res) => {
  let found = null;
  for (const r of meta.values()) {
    if (r.deleteToken === req.params.token) { found = r; break; }
  }
  if (found) { removeFile(found.id); persist(); }
  const wantsJson = req.query.json === '1' || (req.headers['accept'] || '').indexOf('application/json') !== -1;
  if (wantsJson) return res.status(found ? 200 : 404).json({ deleted: !!found });
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  if (!found) return res.status(404).send(miniPage(req, 'badlink'));
  res.send(miniPage(req, 'deleted'));
});

const unlockLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    res.status(429).setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Security-Policy', PAGE_CSP);
    res.send(miniPage(req, 'error'));
  },
});

app.post('/unlock/:file', unlockLimiter, express.urlencoded({ extended: false, limit: '4kb' }), (req, res) => {
  const param = req.params.file;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  if (!/^[A-Za-z0-9._-]{1,80}$/.test(param)) return res.status(404).send(miniPage(req, 'notfound'));
  const dot = param.indexOf('.');
  const id = dot === -1 ? param : param.slice(0, dot);
  const record = meta.get(id);
  if (!record || !record.pwHash) return res.status(404).send(miniPage(req, 'notfound'));
  const pw = (req.body && typeof req.body.pw === 'string') ? req.body.pw : '';
  let ok = false;
  try {
    const h = crypto.scryptSync(pw, record.pwSalt, 32).toString('hex');
    ok = h.length === record.pwHash.length && crypto.timingSafeEqual(Buffer.from(h), Buffer.from(record.pwHash));
  } catch (_) { ok = false; }
  if (!ok) return res.status(401).send(passwordPage(req, param, true));
  res.setHeader('Set-Cookie', `ul_${id}=${unlockToken(id)}; Path=/; Max-Age=3600; HttpOnly; SameSite=Lax`);
  res.redirect(302, '/' + param);
});

app.post('/rename', uploadLimiter, express.json({ limit: '8kb' }), (req, res) => {
  const body = req.body || {};
  const id = typeof body.id === 'string' ? body.id : '';
  const token = typeof body.token === 'string' ? body.token : '';
  let name = typeof body.name === 'string' ? body.name.trim() : '';
  const record = meta.get(id);
  if (!record || !token || record.deleteToken !== token) return res.status(404).json({ error: 'not found' });
  name = name.replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 200);
  if (!name) return res.status(400).json({ error: 'empty name' });
  if (!record.note) {
    const origExt = path.extname(record.name);
    if (origExt && !name.toLowerCase().endsWith(origExt.toLowerCase())) name += origExt;
  }
  record.name = name;
  persist();
  res.json({ ok: true, name: record.name });
});

app.get('/qr/:file', async (req, res) => {
  const param = req.params.file;
  if (!/^[A-Za-z0-9._-]{1,80}$/.test(param)) return res.status(400).end();
  const url = `${baseFor(req)}/${param}`;
  try {
    const svg = await QRCode.toString(url, { type: 'svg', margin: 1, width: 200, color: { dark: '#161410', light: '#ffffff' } });
    res.setHeader('Content-Type', 'image/svg+xml');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(svg);
  } catch (_) {
    res.status(500).end();
  }
});

app.post('/album', uploadLimiter, express.json({ limit: '64kb' }), (req, res) => {
  const body = req.body || {};
  const rawIds = Array.isArray(body.ids) ? body.ids : [];
  const items = [];
  for (const raw of rawIds) {
    if (typeof raw !== 'string') continue;
    const dot = raw.indexOf('.');
    const id = dot === -1 ? raw : raw.slice(0, dot);
    const rec = meta.get(id);
    if (!rec) continue;
    if (rec.expires && Date.now() > rec.expires) continue;
    if (items.indexOf(id) === -1) items.push(id);
  }
  if (items.length < 2) return res.status(400).json({ error: 'need at least 2 files' });
  if (items.length > 100) items.length = 100;
  let albumId;
  do { albumId = generateId(8); } while (albums.has(albumId) || meta.has(albumId));
  let aname = typeof body.name === 'string' ? body.name.trim().replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 120) : '';
  const album = { id: albumId, items, created: Date.now(), expires: parseExpiry(body.expiry), name: aname };
  albums.set(albumId, album);
  writeAlbums();
  res.json({ url: baseFor(req) + '/a/' + albumId, count: items.length, name: album.name || '' });
});

app.get('/a/:albumId.zip', (req, res, next) => {
  const album = albums.get(req.params.albumId);
  if (!album) return next();
  if (album.expires && Date.now() > album.expires) { albums.delete(album.id); writeAlbums(); return next(); }
  const entries = [];
  for (const id of album.items) {
    const rec = meta.get(id);
    if (!rec) continue;
    if (rec.expires && Date.now() > rec.expires) continue;
    if (rec.pwHash || rec.maxDownloads > 0 || rec.note) continue;
    const fp = path.join(uploadsDir, rec.filename);
    if (!fs.existsSync(fp)) continue;
    entries.push({ fp, name: rec.name });
  }
  if (!entries.length) return next();
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', contentDisposition('attachment', `${(album.name || 'album-' + album.id).replace(/[\\/]/g, '_')}.zip`));
  res.setHeader('Cache-Control', 'no-store');
  const zip = archiver('zip', { store: true });
  zip.on('error', () => { try { res.destroy(); } catch (_) {} });
  res.on('close', () => { try { zip.abort(); } catch (_) {} });
  zip.pipe(res);
  const seen = new Map();
  for (const e of entries) {
    let n = String(e.name).replace(/[\\/]/g, '_') || 'file';
    const k = n.toLowerCase();
    if (seen.has(k)) { const c = seen.get(k) + 1; seen.set(k, c); const d = n.lastIndexOf('.'); n = d > 0 ? `${n.slice(0, d)} (${c})${n.slice(d)}` : `${n} (${c})`; }
    else seen.set(k, 1);
    zip.file(e.fp, { name: n });
  }
  zip.finalize();
});

app.get('/a/:albumId', (req, res, next) => {
  const album = albums.get(req.params.albumId);
  if (!album) return next();
  if (album.expires && Date.now() > album.expires) { albums.delete(album.id); writeAlbums(); return next(); }
  const lang = pickLang(req);
  const en = lang === 'en';
  const L = en
    ? { title: album.name || 'Album', n: 'files', expires: 'expires', never: 'no expiry', empty: 'These files are no longer available.', file: 'file' }
    : { title: album.name || 'Album', n: 'files', expires: 'expires', never: 'no expiry', empty: 'These files are no longer available.', file: 'file' };
  const rows = [];
  for (const id of album.items) {
    const rec = meta.get(id);
    if (!rec) continue;
    if (rec.expires && Date.now() > rec.expires) continue;
    const fn = String(rec.name).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const isImg = !(rec.maxDownloads > 0) && (rec.mime || '').indexOf('image/') === 0;
    const link = rec.note ? '/n/' + id : '/p/' + id;
    const thumb = isImg ? `<img class="althumb" src="/${id}" alt="" loading="lazy">` : `<span class="alicon">${rec.note ? (en ? 'note' : 'text') : L.file}</span>`;
    rows.push(`<a class="alitem" href="${link}"><span class="althumbwrap">${thumb}</span><span class="alinfo"><span class="alname">${fn}</span><span class="alsize">${formatBytes(rec.size, STRINGS[lang].js.units)}</span></span></a>`);
  }
  const expires = album.expires ? new Date(album.expires).toISOString().slice(0, 16).replace('T', ' ') + ' UTC' : L.never;
  const css = `.almeta{color:var(--muted);font-weight:600;font-size:.9em;margin:.2rem 0 1.2rem}
.aldl{margin:0 0 1.2rem}
.allist{display:flex;flex-direction:column;gap:.8rem}
.alitem{display:flex;align-items:center;gap:.9rem;padding:.7rem .85rem;background:var(--card);
        border:2px solid var(--ink);border-radius:14px;box-shadow:4px 4px 0 var(--shadow);
        text-decoration:none;color:var(--ink);transition:transform .1s ease,box-shadow .1s ease}
.alitem:hover{transform:translate(-1px,-1px);box-shadow:5px 5px 0 var(--shadow);border-color:var(--accent)}
.althumbwrap{flex:0 0 auto;width:48px;height:48px;border-radius:10px;overflow:hidden;background:var(--bg);
             border:2px solid var(--ink);display:flex;align-items:center;justify-content:center}
.althumb{width:100%;height:100%;object-fit:cover;display:block}
.alicon{font-size:.7em;font-weight:800;color:var(--muted);text-transform:uppercase}
.alinfo{min-width:0;display:flex;flex-direction:column}
.alname{word-break:break-all;font-weight:700;font-size:.95em}
.alsize{color:var(--muted);font-weight:600;font-size:.82em;margin-top:.1rem}`;
  const zippable = album.items.some((id) => {
    const rec = meta.get(id);
    return rec && !(rec.expires && Date.now() > rec.expires) && !rec.pwHash && !(rec.maxDownloads > 0) && !rec.note;
  });
  const dlBtn = (rows.length && zippable) ? `<p class="aldl"><a class="btn" href="/a/${album.id}.zip">download all (.zip)</a></p>` : '';
  const inner = rows.length ? `<div class="allist">${rows.join('')}</div>` : `<p class="lead">${L.empty}</p>`;
  const main = `<div class="content">
  <h1>${escHtml(L.title)}</h1>
  <p class="almeta">${rows.length} ${L.n}&nbsp;&nbsp;\u00b7&nbsp;&nbsp;${L.expires}: ${expires}</p>
  ${dlBtn}
  ${inner}
</div>`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  res.send(pageChrome(req, { title: `${escHtml(L.title)} / ${CONFIG.siteName}`, main, css }));
});

function mdInline(t) {
  t = t.replace(/`([^`]+)`/g, function (m, c) { return '<code>' + c + '</code>'; });
  t = t.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');
  t = t.replace(/~~([^~\n]+)~~/g, '<del>$1</del>');
  t = t.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)/g, '<a href="$2" rel="noreferrer nofollow ugc" target="_blank">$1</a>');
  return t;
}
function renderMarkdown(src) {
  let s = String(src).replace(/\r\n/g, '\n').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const blocks = [];
  s = s.replace(/```([\s\S]*?)```/g, function (m, code) { blocks.push(code.replace(/^\n/, '').replace(/\n$/, '')); return '\u0000CB' + (blocks.length - 1) + '\u0000'; });
  const lines = s.split('\n');
  const out = [];
  let para = [];
  let i = 0;
  function flush() { if (para.length) { out.push('<p>' + para.map(mdInline).join('<br>') + '</p>'); para = []; } }
  while (i < lines.length) {
    const line = lines[i];
    const cb = line.match(/^\u0000CB(\d+)\u0000$/);
    if (cb) { flush(); out.push('<pre><code>' + (blocks[+cb[1]] || '') + '</code></pre>'); i++; continue; }
    if (/^\s*$/.test(line)) { flush(); i++; continue; }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) { flush(); const lvl = h[1].length + 1; out.push('<h' + lvl + '>' + mdInline(h[2]) + '</h' + lvl + '>'); i++; continue; }
    if (/^(---|\*\*\*)\s*$/.test(line)) { flush(); out.push('<hr>'); i++; continue; }
    if (/^&gt;\s?/.test(line)) { flush(); const q = []; while (i < lines.length && /^&gt;\s?/.test(lines[i])) { q.push(mdInline(lines[i].replace(/^&gt;\s?/, ''))); i++; } out.push('<blockquote>' + q.join('<br>') + '</blockquote>'); continue; }
    if (/^\s*[-*]\s+/.test(line)) { flush(); const it = []; while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) { it.push('<li>' + mdInline(lines[i].replace(/^\s*[-*]\s+/, '')) + '</li>'); i++; } out.push('<ul>' + it.join('') + '</ul>'); continue; }
    if (/^\s*\d+\.\s+/.test(line)) { flush(); const it = []; while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) { it.push('<li>' + mdInline(lines[i].replace(/^\s*\d+\.\s+/, '')) + '</li>'); i++; } out.push('<ol>' + it.join('') + '</ol>'); continue; }
    para.push(line); i++;
  }
  flush();
  return out.join('\n');
}

app.post('/note', uploadLimiter, express.json({ limit: '256kb' }), async (req, res) => {
  const body = req.body || {};
  const lang = pickLang(req);
  const content = typeof body.content === 'string' ? body.content : '';
  if (!content.replace(/\s/g, '')) return res.status(400).json({ error: 'empty' });
  if (Buffer.byteLength(content, 'utf8') > 200 * 1024) return res.status(413).json({ error: 'too large' });
  const id = uniqueId();
  const filename = id + '.md';
  const filePath = path.join(uploadsDir, filename);
  try { fs.writeFileSync(filePath, content, 'utf8'); } catch (_) { return res.status(500).json({ error: 'write failed' }); }
  const r = await finalizeStoredFile({
    lang, filePath, mimetype: 'text/markdown', expiryRaw: body.expiry,
    maxDownloadsRaw: body.maxdl, password: body.password,
    id, filename, originalName: (typeof body.name === 'string' && body.name.trim()) ? body.name.trim().replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 200) : 'note.md', note: true,
  });
  if (!r.ok) return res.status(r.status || 500).json({ error: r.error || 'error' });
  const base = baseFor(req);
  res.json({ url: base + '/n/' + id, deletion_url: base + '/d/' + r.deleteToken, name: r.record.name, protected: !!r.record.pwHash, max_downloads: r.record.maxDownloads, expires: r.record.expires || null });
});

app.get('/n/:file', (req, res, next) => {
  const param = req.params.file;
  const dot = param.indexOf('.');
  const id = dot === -1 ? param : param.slice(0, dot);
  const record = meta.get(id);
  if (!record || !record.note) return next();
  if (record.expires && Date.now() > record.expires) { removeFile(id); persist(); return next(); }
  const filePath = path.join(uploadsDir, record.filename);
  if (!fs.existsSync(filePath)) { meta.delete(id); persist(); return next(); }
  if (record.pwHash && !hasValidUnlock(req, id)) {
    res.status(401).setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Security-Policy', PAGE_CSP);
    return res.send(passwordPage(req, param, false));
  }
  let raw = '';
  try { raw = fs.readFileSync(filePath, 'utf8'); } catch (_) { return next(); }
  const isBurn = record.maxDownloads > 0;
  if (isBurn) {
    record.downloads = (record.downloads || 0) + 1;
    if (record.downloads > record.maxDownloads) { removeFile(id); persist(); return next(); }
    persist();
    if (record.downloads >= record.maxDownloads) res.on('finish', () => { removeFile(id); persist(); });
  }
  const lang = pickLang(req);
  const en = lang === 'en';
  const flags = [];
  if (isBurn) flags.push(en ? 'self-destructs after ' + record.maxDownloads + ' views' : 'self-destructs after ' + record.maxDownloads + ' views');
  const flagsHtml = flags.length ? `<p class="noteflags">${flags.map((f) => '\u2022 ' + f).join('&nbsp;&nbsp;')}</p>` : '';
  const css = `.noteflags{color:var(--muted);font-size:.82rem;margin:0 0 1.2rem}
.note-body{font-size:1rem;line-height:1.7;overflow-wrap:break-word}
.note-body h2,.note-body h3,.note-body h4{letter-spacing:-.01em;margin:1.6rem 0 .6rem;line-height:1.25}
.note-body h2{font-size:1.4rem}
.note-body h3{font-size:1.2rem}
.note-body h4{font-size:1.05rem}
.note-body p{margin:.8rem 0}
.note-body a{color:var(--accent-ink);text-decoration:underline;text-underline-offset:2px;text-decoration-color:var(--accent)}
.note-body ul,.note-body ol{margin:.8rem 0;padding-left:1.4rem}
.note-body li{margin:.3rem 0}
.note-body blockquote{margin:1rem 0;padding:.35rem 0 .35rem 1rem;border-left:3px solid var(--line);color:var(--muted)}
.note-body code{font-family:var(--mono);font-size:.88em;background:var(--track);padding:.1rem .35rem;border-radius:5px}
.note-body pre{background:var(--track);border-radius:12px;padding:1rem 1.1rem;overflow:auto;margin:1.1rem 0}
.note-body pre code{background:none;padding:0;font-size:.85rem;line-height:1.55}
.note-body hr{border:0;border-top:1px solid var(--line);margin:1.6rem 0}
[data-theme="dark"] .note-body a{color:var(--accent)}`;
  const noteH1 = (record.name && record.name !== 'note.md') ? `<h1 class="notetitle">${escHtml(record.name.replace(/\.md$/i, ''))}</h1>` : '';
  const main = `<div class="content">${noteH1}${flagsHtml}<article class="note-body">${renderMarkdown(raw)}</article></div>`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', (isBurn || record.pwHash) ? 'no-store, no-cache, must-revalidate, private' : 'public, max-age=600');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  const noteTitle = (record.name && record.name !== 'note.md') ? record.name.replace(/\.md$/i, '') : (en ? 'Note' : 'Note');
  res.send(pageChrome(req, { title: `${noteTitle} / ${CONFIG.siteName}`, main, css }));
});

app.get('/p/:file', (req, res, next) => {
  const param = req.params.file;
  const dot = param.indexOf('.');
  const id = dot === -1 ? param : param.slice(0, dot);
  const record = meta.get(id);
  if (!record) return next();
  if (record.expires && Date.now() > record.expires) { removeFile(id); persist(); return next(); }
  const filePath = path.join(uploadsDir, record.filename);
  if (!fs.existsSync(filePath)) { meta.delete(id); persist(); return next(); }
  if (record.pwHash && !hasValidUnlock(req, id)) {
    res.status(401).setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Security-Policy', PAGE_CSP);
    return res.send(passwordPage(req, param, false));
  }
  const lang = pickLang(req);
  const PV = { download: 'download', size: 'size', expires: 'expires', never: 'no expiry',
    burns: 'self-destructs after {n} download(s)', protected: 'password protected',
    copy_link: 'copy link', copy_direct: 'copy direct link', burn_note: 'Preview disabled so it does not use up a download.' };
  const js = STRINGS[lang].js;
  const isBurn = record.maxDownloads > 0;
  const enc = encodeURIComponent(param);
  const expires = record.expires ? new Date(record.expires).toISOString().slice(0, 16).replace('T', ' ') + ' UTC' : PV.never;
  const m = record.mime || '';
  let media = '';
  if (!isBurn) {
    if (m.indexOf('image/') === 0) { const alpha = /png|gif|webp|avif|svg/.test(m); media = `<a class="pvcard pvhasbg" href="/${enc}" target="_blank" rel="noopener"><span class="pvbg" style="background-image:url('/${enc}')"></span><img class="pvmedia${alpha ? ' checker' : ''}" src="/${enc}" alt=""></a>`; }
    else if (m.indexOf('video/') === 0) media = `<div class="pvcard"><video class="pvmedia" src="/${enc}" controls preload="metadata" playsinline></video></div>`;
    else if (m.indexOf('audio/') === 0) media = `<div class="pvcard pvaudiocard"><audio class="pvaudio" src="/${enc}" controls preload="metadata"></audio></div>`;
  }
  if (!media) {
    const extRaw = (String(record.name).split('.').pop() || 'file').slice(0, 6);
    const ext = extRaw.replace(/[^a-z0-9]/gi, '').toUpperCase() || 'FILE';
    const note = isBurn ? `<p class="pvburnnote">${PV.burn_note}</p>` : '';
    media = `<div class="pvcard pvfilecard"><span class="pvext">.${ext}</span>${note}</div>`;
  }
  const flags = [];
  if (isBurn) flags.push(PV.burns.replace('{n}', record.maxDownloads));
  if (record.pwHash) flags.push(PV.protected);
  const flagsHtml = flags.length ? `<p class="pvflags">${flags.map((f) => '\u2022 ' + f).join('&nbsp;&nbsp;')}</p>` : '';
  const fn = String(record.name).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const css = `.wrap{max-width:800px}
.viewer{margin-top:clamp(1.2rem,4vh,2rem)}
.pvcard{display:block;background:var(--card);border:2px solid var(--ink);border-radius:16px;
        box-shadow:6px 6px 0 var(--shadow);overflow:hidden;text-decoration:none}
a.pvcard:hover{border-color:var(--accent)}
.pvmedia{display:block;width:100%;height:auto;max-height:72vh;object-fit:contain}
.pvhasbg{position:relative}
.pvbg{position:absolute;inset:0;background-size:cover;background-position:center;filter:blur(32px) saturate(1.15) brightness(.85);transform:scale(1.2)}
.pvhasbg .pvmedia{position:relative;z-index:1}
.checker{background:repeating-conic-gradient(rgba(127,138,160,.14) 0% 25%, transparent 0% 50%) 0 0/26px 26px}
.pvaudiocard{padding:1.4rem 1.1rem}
.pvaudio{width:100%;display:block}
.pvfilecard{padding:3rem 1rem;text-align:center}
.pvext{display:inline-block;font-weight:900;font-size:1.6em;color:var(--accent);
       border:2px dashed var(--accent);border-radius:14px;padding:.7rem 1.4rem}
.pvburnnote{color:var(--muted);font-weight:600;font-size:.9em;margin:1rem 0 0}
.pvinfo{margin-top:1.3rem;text-align:center}
.pvfn{word-break:break-all;margin:0;font-size:1.25em;font-weight:900}
.pvmeta{color:var(--muted);font-weight:600;font-size:.9em;margin:.3rem 0 0}
.pvflags{color:var(--muted);font-weight:600;font-size:.85em;margin:.5rem 0 0}
.pvact{display:flex;flex-wrap:wrap;gap:1.1rem;align-items:center;justify-content:center;margin-top:1.2rem}`;
  const main = `<main class="viewer">
  ${media}
  <div class="pvinfo">
    <h1 class="pvfn">${fn}</h1>
    <p class="pvmeta">${PV.size}: ${formatBytes(record.size, js.units)}&nbsp;&nbsp;\u00b7&nbsp;&nbsp;${PV.expires}: ${expires}</p>
    ${flagsHtml}
    <div class="pvact">
      <a class="btn" href="/${enc}?dl=1">${PV.download}</a>
      <button type="button" class="act" data-copy="${baseFor(req)}/p/${enc}" data-ok="${js.copied_ok}">${PV.copy_link}</button>
      <button type="button" class="act" data-copy="${baseFor(req)}/${enc}?dl=1" data-ok="${js.copied_ok}">${PV.copy_direct}</button>
    </div>
  </div>
</main>`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self'; font-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  res.send(pageChrome(req, { title: `${record.name} / ${CONFIG.siteName}`, main, css }));
});

app.get('/:file', (req, res, next) => {
  const param = req.params.file;
  const dot = param.indexOf('.');
  const id = dot === -1 ? param : param.slice(0, dot);
  const record = meta.get(id);
  if (!record) return next();

  if (record.expires && Date.now() > record.expires) {
    removeFile(id); persist();
    return next();
  }

  const filePath = path.join(uploadsDir, record.filename);
  if (!fs.existsSync(filePath)) {
    meta.delete(id); persist();
    return next();
  }

  if (record.pwHash && !hasValidUnlock(req, id)) {
    res.status(401).setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Security-Policy', PAGE_CSP);
    return res.send(passwordPage(req, param, false));
  }

  const host = (req.headers['host'] || '').toLowerCase();
  const viaOnion = host.endsWith('.onion');
  const isBurn = record.maxDownloads > 0;
  const inline = INLINE_SAFE.has(record.mime);
  const noCache = isBurn || !!record.pwHash;

  if (Date.now() - (record.lastAccess || 0) > 3600 * 1000) { record.lastAccess = Date.now(); persist(); }

  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Content-Security-Policy', "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; sandbox");
  res.setHeader('Cache-Control', noCache ? 'no-store, no-cache, must-revalidate, private' : 'public, max-age=31536000, immutable');
  res.setHeader('Content-Type', inline ? record.mime : 'application/octet-stream');
  const forceDl = req.query.dl === '1';
  res.setHeader('Content-Disposition', contentDisposition((inline && !forceDl) ? 'inline' : 'attachment', record.name));
  res.setHeader('Accept-Ranges', 'bytes');

  if (CONFIG.xAccel && !viaOnion && !isBurn) {
    res.setHeader('X-Accel-Redirect', '/_dl/' + encodeURIComponent(record.filename));
    return res.end();
  }

  let size;
  try { size = fs.statSync(filePath).size; } catch (_) { return next(); }

  if (isBurn) {
    record.downloads = (record.downloads || 0) + 1;
    if (record.downloads > record.maxDownloads) {
      removeFile(id); persist();
      return next();
    }
    persist();
    const isLast = record.downloads >= record.maxDownloads;
    res.setHeader('Content-Length', size);
    if (isLast) res.on('finish', () => { removeFile(id); persist(); });
    return fs.createReadStream(filePath)
      .on('error', () => { if (!res.headersSent) res.status(500).end(); })
      .pipe(res);
  }

  const range = req.headers['range'];
  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
    if (m && (m[1] !== '' || m[2] !== '')) {
      let start, end;
      if (m[1] === '') { start = Math.max(0, size - parseInt(m[2], 10)); end = size - 1; }
      else { start = parseInt(m[1], 10); end = m[2] === '' ? size - 1 : Math.min(parseInt(m[2], 10), size - 1); }
      if (isNaN(start) || isNaN(end) || start > end || start < 0 || start >= size) {
        res.status(416).setHeader('Content-Range', `bytes */${size}`);
        return res.end();
      }
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${end}/${size}`);
      res.setHeader('Content-Length', end - start + 1);
      return fs.createReadStream(filePath, { start, end })
        .on('error', () => { if (!res.headersSent) res.status(500).end(); })
        .pipe(res);
    }
  }

  res.setHeader('Content-Length', size);
  fs.createReadStream(filePath)
    .on('error', () => { if (!res.headersSent) res.status(500).end(); })
    .pipe(res);
});

app.use((req, res) => {
  res.status(404).setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  res.send(miniPage(req, 'notfound'));
});

app.use((err, req, res, _next) => {
  console.error('error:', err && err.message ? err.message : err);
  if (res.headersSent) return;
  res.status(500).setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Content-Security-Policy', PAGE_CSP);
  res.send(miniPage(req, 'error'));
});

function pageChrome(req, opts) {
  const lang = pickLang(req);
  const S = STRINGS[lang];
  const i18n = `<script>window.LANG=${JSON.stringify(lang)};window.T=${JSON.stringify(S.js)};</script>`;
  const footer = opts.footer != null ? opts.footer
    : `<a class="backlink" href="/">${(S.mini && S.mini.home) || '\u2190 home'}</a>`;
  return `<!doctype html><html lang="${lang}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escHtml(opts.title)}</title>
<meta name="robots" content="${escHtml(opts.robots || 'noindex')}">
<link rel="icon" type="image/svg+xml" href="/assets/favicon.svg?v=3">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon-32.png?v=3">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png?v=3">
<link rel="stylesheet" href="/assets/app.css?v=5">${opts.css ? `
<style>${opts.css}</style>` : ''}
<script>(function(){try{var t=localStorage.getItem('theme')||((window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches)?'dark':'light');document.documentElement.setAttribute('data-theme',t);}catch(e){}})();</script>
</head>
<body><div class="wrap">
<header class="site-head"><div class="hrow">
  <a class="brand" href="/" aria-label="${CONFIG.siteName}"></a>
  <div class="toggles">
    <button type="button" class="tt" id="themeBtn" aria-label="Theme"><svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><circle cx="8" cy="8" r="6.6" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M8 1.4a6.6 6.6 0 000 13.2z" fill="currentColor"/></svg></button>
  </div>
</div></header>
${opts.main}
<footer class="pfoot">${footer}</footer>
</div>
<img class="corner" src="${randMascot()}" alt="" aria-hidden="true">
${i18n}
<script src="/assets/app.js?v=3"></script>
</body></html>`;
}

function miniPage(req, kind) {
  const lang = pickLang(req);
  const S = STRINGS[lang];
  const m = S.mini[kind];
  const code = kind === 'notfound' ? '404' : kind === 'badlink' ? '410' : kind === 'deleted' ? '\u2713' : '500';
  const errImg = { notfound: '/assets/404.svg?v=2', method: '/assets/405.svg?v=2' }[kind];
  const imgHtml = errImg ? `<img class="perr-img" src="${errImg}" alt="">` : '';
  const main = `<main class="pcenter">
  <section class="phero">
    <div>${imgHtml}<div class="eyebrow">${code}</div><h1>${m.title}</h1>${SQUIG}<p>${m.msg}</p></div>
  </section>
</main>`;
  return pageChrome(req, { title: `${m.title} / ${CONFIG.siteName}`, main });
}

function passwordPage(req, fileParam, isError) {
  const lang = pickLang(req);
  const S = STRINGS[lang];
  const P = S.pw;
  const errHtml = isError ? `<p class="pwerr">${P.wrong}</p>` : '';
  const css = `.lockicon{font-size:1.5rem;line-height:1}
.pwform{display:flex;flex-direction:column;gap:.6rem;margin:1.3rem auto 0;max-width:240px}
.pwinput{border:0;border-bottom:1px solid var(--line);background:none;color:var(--ink);font:inherit;padding:.3rem .4rem;text-align:center}
.pwinput::placeholder{color:var(--muted)}
.pwinput:focus{outline:0;border-bottom-color:var(--accent)}
.pwbtn{width:100%}
.pwerr{color:var(--red);font-size:.9em;margin:.7rem 0 0}`;
  const main = `<main class="pcenter">
  <section class="phero">
    <div>
      <div class="lockicon">\uD83D\uDD12</div>
      <h1>${P.title}</h1>${SQUIG}
      <p>${P.msg}</p>
      ${errHtml}
      <form class="pwform" method="POST" action="/unlock/${fileParam}">
        <input type="password" name="pw" class="pwinput" placeholder="${P.placeholder}" autocomplete="off" autofocus required>
        <button type="submit" class="btn pwbtn">${P.submit}</button>
      </form>
    </div>
  </section>
</main>`;
  return pageChrome(req, { title: `${P.title} / ${CONFIG.siteName}`, main, css });
}

function rulesPage(req) {
  const lang = pickLang(req);
  const S = STRINGS[lang];
  const R = S.rules;
  const mail = CONFIG.abuseEmail;
  const lead = R.lead.replace('{site}', CONFIG.siteName);
  const report = R.report.replace('{mail}', `<a href="mailto:${mail}">${mail}</a>`);
  const css = `.keep{margin:1rem 0 0;font-size:.95em;color:var(--muted)}
.keep div{margin:.4rem 0}
.keep .yes::before{content:"+ ";color:var(--accent);font-weight:700}
.keep .no::before{content:"\u2212 ";color:var(--red);font-weight:700}`;
  const main = `
<section class="phero">
  <div><h1>${R.title}</h1>${SQUIG}<p>${lead}</p></div>
</section>
<div class="content">
  <h2>${R.hProhibited}</h2>
  <ul>
    <li>${R.csam}</li><li>${R.terror}</li><li>${R.malware}</li>
    <li>${R.abuse}</li><li>${R.illegal}</li>
  </ul>
  <h2>${R.hPrivacy}</h2>
  <p class="lead">${R.privacy}</p>
  <div class="keep"><div class="yes">${R.keepYes}</div><div class="no">${R.keepNo}</div></div>
  <h2>${R.hReport}</h2>
  <p>${report}</p>
</div>`;
  return pageChrome(req, { title: `${R.title} / ${CONFIG.siteName}`, main, css, robots: 'index, follow', footer: `<a class="backlink" href="/">${R.back}</a>` });
}

const CRYPTO_ICONS = {
  btc: '<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><circle cx="16" cy="16" r="16" fill="#F7931A"/><path fill="#fff" d="M22.6 13.9c.3-2.1-1.3-3.2-3.5-4l.7-2.8-1.7-.4-.7 2.7c-.5-.1-.9-.2-1.4-.3l.7-2.8-1.7-.4-.7 2.8c-.4-.1-.8-.2-1.1-.3l-2.4-.6-.5 1.8s1.3.3 1.3.3c.7.2.8.6.8 1l-.8 3.2v.1l-1.1 4.5c-.1.2-.3.5-.8.4 0 0-1.3-.3-1.3-.3l-.9 2 2.2.6c.4.1.8.2 1.2.3l-.7 2.9 1.7.4.7-2.8c.5.1.9.2 1.4.3l-.7 2.8 1.7.4.7-2.9c2.9.6 5.1.3 6-2.3.7-2.1 0-3.3-1.5-4.1 1.1-.2 2-1 2.2-2.5zm-4 5.4c-.5 2.1-4 1-5.2.7l.9-3.7c1.2.3 4.9.9 4.3 3zm.6-5.4c-.5 1.9-3.4.9-4.4.7l.8-3.4c1 .3 4.1.7 3.6 2.7z"/></svg>',
  eth: '<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><circle cx="16" cy="16" r="16" fill="#627EEA"/><g fill="#fff"><polygon fill-opacity=".6" points="16,4 16,12.9 23.5,16.2"/><polygon points="16,4 8.5,16.2 16,12.9"/><polygon fill-opacity=".6" points="16,21.6 16,27.6 23.5,17.6"/><polygon points="16,27.6 16,21.6 8.5,17.6"/><polygon fill-opacity=".2" points="16,20.2 23.5,16.2 16,12.9"/><polygon fill-opacity=".6" points="8.5,16.2 16,20.2 16,12.9"/></g></svg>',
  ltc: '<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><circle cx="16" cy="16" r="16" fill="#345D9D"/><path fill="#fff" d="M13.9 7.5h3.9l-1.8 7 2.6-.9-.6 2.4-2.6.8-1 3.9h7.1l-.7 2.8H10.6l1.4-5.3-2.3.8.6-2.4 2.3-.8z"/></svg>',
  xmr: '<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><circle cx="16" cy="16" r="16" fill="#F60"/><path fill="#fff" d="M7 23v-13l9 9 9-9v13h-3.6v-6.7L16 21.7l-5.4-5.4V23z"/></svg>',
};

const DONATE = [
  { ticker: 'BTC', name: 'Bitcoin', qr: 'btc', addr: 'bc1qqfz8fn2mxmelv3mwyzd4erfc8jrhxh4lgr27ym' },
  { ticker: 'ETH', name: 'Ethereum', qr: 'eth', addr: '0x52DdB9c20DfFB112b907a2221120df69D4AdcE82' },
  { ticker: 'LTC', name: 'Litecoin', qr: 'ltc', addr: 'LWXkSyQQkhYX2rmzjXYJ2jjDCL743P2uRM' },
  { ticker: 'XMR', name: 'Monero', qr: 'xmr', addr: '86SNrcsis9Z4dNb5LJaEkbKWGtbRiSqXEeCr6wJG4pKd7eYNoWqee6t2Ukzek2UAh4DuT3GmVWJCU6CU3dxNgE7oTU7s61f' },
];

function apiPage(req) {
  const base = CONFIG.baseUrl;
  const maxOne = formatBytes(CONFIG.maxFileSize, STRINGS.en.js.units);
  const maxBig = formatBytes(CONFIG.maxChunkedSize, STRINGS.en.js.units);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const block = (code) => `<pre class="code"><code>${esc(code)}</code></pre>`;
  const curlUp = `curl -F file=@photo.jpg ${base}/upload`;
  const curlResp = `{\n  "url": "${base}/aB3xz9.jpg",\n  "deletion_url": "${base}/d/9f2c\u2026",\n  "name": "photo.jpg",\n  "size": 51234,\n  "expires": 0\n}`;
  const curlOpts = `curl -F file=@clip.mp4 \\\n     -F expiry=24 \\\n     -F maxdl=5 \\\n     -F password=hunter2 \\\n     ${base}/upload`;
  const curlDl = `# add ?dl=1 to any link to force a download\n${base}/aB3xz9.jpg?dl=1`;
  const css = `.content h2{margin-top:2.2rem}
.code{background:var(--card);border:2px solid var(--ink);border-radius:12px;box-shadow:4px 4px 0 var(--shadow);
      padding:.85rem 1rem;overflow-x:auto;margin:.7rem 0 0}
.code code{font-family:var(--mono);font-size:.86em;line-height:1.55;white-space:pre;color:var(--ink)}
.tbl{width:100%;border-collapse:collapse;margin-top:.7rem;font-size:.92em}
.tbl th,.tbl td{text-align:left;padding:.45rem .6rem;border-bottom:2px dashed var(--line)}
.tbl th{font-weight:800}
.tbl td:first-child{font-family:var(--mono);color:var(--teal);font-weight:600;white-space:nowrap}
.apilead{color:var(--muted);font-weight:600}`;
  const main = `
<section class="phero">
  <div><h1>API</h1>${SQUIG}<p>No keys, no accounts. Just POST a file and get a link back.</p></div>
</section>
<div class="content">
  <p class="apilead">Every response is JSON. Single files up to ${maxOne}; larger files (up to ${maxBig}) use the chunked endpoints the web uploader uses.</p>

  <h2>Upload a file</h2>
  <p>Send <code>multipart/form-data</code> with a <code>file</code> field to <code>/upload</code>.</p>
  ${block(curlUp)}

  <h2>Response</h2>
  ${block(curlResp)}

  <h2>Options</h2>
  <p>All optional, sent as extra form fields:</p>
  <table class="tbl">
    <tr><th>field</th><th>meaning</th></tr>
    <tr><td>expiry</td><td>hours until auto-delete: 0 (never), 1, 24, 168, 720</td></tr>
    <tr><td>maxdl</td><td>self-destruct after N downloads (0 = unlimited)</td></tr>
    <tr><td>password</td><td>require a password to open the file</td></tr>
  </table>
  ${block(curlOpts)}

  <h2>Force a download</h2>
  ${block(curlDl)}

  <h2>ShareX</h2>
  <p>Grab a ready-made config and import it into ShareX: <a href="/sharex">${base}/sharex</a></p>

  <h2>Delete</h2>
  <p>Each upload returns a <code>deletion_url</code>. Open it (or GET it) to remove the file early.</p>
</div>`;
  return pageChrome(req, { title: `API / ${CONFIG.siteName}`, main, css, footer: `<a class="backlink" href="/">\u2190 home</a>` });
}

function donatePage(req) {
  const lang = pickLang(req);
  const S = STRINGS[lang];
  const D = S.donate;
  const coins = DONATE.map((c) => `
    <div class="coin">
      <div class="coin-top">
        <span class="cic">${CRYPTO_ICONS[c.qr]}</span>
        <span class="tick">${c.ticker}</span>
        <span class="cname">${c.name}</span>
      </div>
      <div class="coin-row">
        <img class="qr" src="/assets/qr/${c.qr}.svg" width="104" height="104" alt="${c.ticker} QR" loading="lazy">
        <div class="addr-box">
          <code class="addr">${c.addr}</code>
          <div><button type="button" class="act" data-copy="${c.addr}" data-ok="${S.js.copied_ok}">${S.js.copy}</button></div>
        </div>
      </div>
    </div>`).join('');
  const css = `.coins{display:flex;flex-direction:column;gap:1.1rem;margin-top:1.2rem}
.coin{background:var(--card);border:2px solid var(--ink);border-radius:16px;box-shadow:4px 4px 0 var(--shadow);overflow:hidden}
.coin-top{display:flex;align-items:center;gap:.55rem;padding:.6rem .95rem;border-bottom:2px dashed var(--line)}
.cic{display:inline-flex;flex:0 0 auto}
.cic svg{width:24px;height:24px;display:block}
.coin-top .tick{font-weight:900}
.coin-top .cname{color:var(--muted);font-weight:600}
.coin-row{display:flex;gap:1rem;padding:.95rem;align-items:center}
.qr{width:104px;height:104px;border:2px solid var(--ink);border-radius:12px;background:#fff;padding:6px;flex:0 0 auto;display:block}
.addr-box{flex:1;min-width:0;display:flex;flex-direction:column;gap:.5rem}
.addr{word-break:break-all;font-family:var(--mono);font-size:.84em;font-weight:600}
.dhint{color:var(--muted);font-weight:600;margin:0}
.thanks{margin:2rem 0 0;font-weight:800;text-align:center}
.thanks::before{content:"\u2665 ";color:var(--accent)}
@media (max-width:480px){.coin-row{flex-direction:column;align-items:flex-start}.addr-box{width:100%}}`;
  const main = `
<section class="phero">
  <div><h1>${D.title}</h1>${SQUIG}<p>${D.intro}</p></div>
</section>
<div class="content">
  <p class="dhint">${D.hint}</p>
  <div class="coins">${coins}</div>
  <p class="thanks">${D.thanks}</p>
</div>`;
  return pageChrome(req, { title: `${D.title} / ${CONFIG.siteName}`, main, css, robots: 'index, follow', footer: `<a class="backlink" href="/">${D.back}</a>` });
}

const server = app.listen(CONFIG.port, () => {
  console.log(`Server listening on port ${CONFIG.port}`);
  console.log(`Public URL: ${CONFIG.baseUrl}`);
  console.log(`Max size: ${formatBytes(CONFIG.maxChunkedSize)} (chunked), ${formatBytes(CONFIG.maxFileSize)} (single)`);
});

function shutdown() {
  console.log('\nShutting down…');
  persistSync();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
